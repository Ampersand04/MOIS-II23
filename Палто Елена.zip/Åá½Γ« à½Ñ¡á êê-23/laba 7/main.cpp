﻿#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <string>

using namespace std;

struct Node {
    char data;
    Node *left, *right;

    Node(char val) : data(val), left(nullptr), right(nullptr) {}
};
void preOrderTraversal(Node* root, vector<char>& traversal) {
    if (root == nullptr) return;

    traversal.push_back(root->data);
    preOrderTraversal(root->left, traversal);
    preOrderTraversal(root->right, traversal);
}
bool isIsomorphic(Node* root1, Node* root2) {
    if (root1 == nullptr && root2 == nullptr) return true;
    if (root1 == nullptr || root2 == nullptr) return false;

    vector<char> traversal1, traversal2;
    preOrderTraversal(root1, traversal1);
    preOrderTraversal(root2, traversal2);

    return traversal1 == traversal2;
}

void deleteNode(Node* root, char key, Node*& target) {
    if (root == nullptr) return;

    if (root->left && root->left->data == key) {
        target = root->left;
        root->left = nullptr;
        delete target;
        return;
    }
    if (root->right && root->right->data == key) {
        target = root->right;
        root->right = nullptr;
        delete target;
        return;
    }

    deleteNode(root->left, key, target);
    deleteNode(root->right, key, target);
}

void addLeaf(Node* root, char key, char leaf) {
    if (root == nullptr) return;

    if (root->data == key) {
        if (root->left == nullptr) {
            root->left = new Node(leaf);
        } else {
            root->right = new Node(leaf);
        }
        return;
    }

    addLeaf(root->left, key, leaf);
    addLeaf(root->right, key, leaf);
}

void writeEdgesToFile(Node* root, ofstream& outputFile) {
    if (root == nullptr) return;

    if (root->left != nullptr) {
        outputFile << root->data << " " << root->left->data << endl;
    }
    if (root->right != nullptr) {
        outputFile << root->data << " " << root->right->data << endl;
    }

    writeEdgesToFile(root->left, outputFile);
    writeEdgesToFile(root->right, outputFile);
}


int height(Node* node) {
    if (node == nullptr) {
        return 0;
    } else {
        int left_height = height(node->left);
        int right_height = height(node->right);

        return 1 + max(left_height, right_height);
    }
}

bool isBalanced(Node* root) {
    if (root == nullptr) {
        return true;
    }

    int left_height = height(root->left);
    int right_height = height(root->right);

    int height_diff = abs(left_height - right_height);

    if (height_diff <= 1 && isBalanced(root->left) && isBalanced(root->right)) {
        return true;
    }

    return false;
}



void appendOutput(bool balanced, int height) {
    const string filename = "output_2.txt";

    ofstream outFile(filename, ios::app);

    if (!outFile.is_open()) {
        cout << "Unable to open file" << endl;
        return;
    }

    outFile << "Balanced: ";
    if (balanced) {
        outFile << "Yes" << endl;
    } else {
        outFile << "No" << endl;
    }

    outFile << "Height: " << height << endl;

    outFile.close();
}

Node* createTree(const vector<pair<char, char>>& edges) {
    unordered_map<char, Node*> nodes;

    Node* root = nullptr;

    for (const auto& edge : edges) {
        char parentData = edge.first;
        char childData = edge.second;

        Node *parentNode, *childNode;

        if (nodes.find(parentData) == nodes.end()) {
            parentNode = new Node(parentData);
            nodes[parentData] = parentNode;

            if (root == nullptr) {
                root = parentNode;
            }
        } else {
            parentNode = nodes[parentData];
        }

        if (nodes.find(childData) == nodes.end()) {
            childNode = new Node(childData);
            nodes[childData] = childNode;
        } else {
            childNode = nodes[childData];
        }

        if (parentNode->left == nullptr) {
            parentNode->left = childNode;
        } else {
            parentNode->right = childNode;
        }
    }

    bool is_balanced = isBalanced(root);
    int tree_height = height(root);
    cout<<is_balanced;
    appendOutput(is_balanced, tree_height);
    return root;
}




int main() {
    ifstream file1("input_1.txt"), file2("input_2.txt");
    ofstream outputFile1("modified_tree_1.txt"), outputFile2("modified_tree_2.txt");
    if (!file1.is_open() || !file2.is_open() || !outputFile1.is_open() || !outputFile2.is_open()) {
        cerr << "Unable to open files." << endl;
        return 1;
    }

    vector<pair<char, char>> edges1, edges2;
    char parent, child;

    while (file1 >> parent >> child) {
        edges1.emplace_back(parent, child);
    }

    while (file2 >> parent >> child) {
        edges2.emplace_back(parent, child);
    }

    Node* root1 = createTree(edges1);
    Node* root2 = createTree(edges2);

    Node* target = nullptr;

    ofstream outputFile("output.txt");
    if (isIsomorphic(root1, root2)) {
        outputFile << "Tree 1 is isomorphic to Tree 2." << endl;
    } else {
        outputFile << "Tree 1 is not isomorphic to Tree 2." << endl;
    }
    // Approach 1: Remove 'k' from Tree 1
    deleteNode(root1, 'k', target);

    // Approach 2: Add 'k' as a leaf to Node 'd' in Tree 2
    addLeaf(root2, 'd', 'k');

    outputFile1 << "Modified Tree 1 (removed 'k') edges:" << endl;
    writeEdgesToFile(root1, outputFile1);

    outputFile2 << "Modified Tree 2 (added 'k') edges:" << endl;
    writeEdgesToFile(root2, outputFile2);

    outputFile1.close();
    outputFile2.close();

    return 0;
}
