#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
using namespace std;
#include <algorithm>
#include <array>
#include <list>
#include <set>


// Создаём структуру, в которой будут храниться результаты dfs и bfs
struct ConnectedComponents{
    vector<vector<int>> dfsComponents;
    vector<vector<int>> bfsComponents;
};

//Если хотим записать/перезаписать данные в файл
void txt_file_input(ConnectedComponents &svasn){
    std::ofstream outputFile; // Создаем объект для записи в файл
    // Открываем файл для записи
    outputFile.open("C:/Users/PC/Desktop/example_output.txt");
    if (outputFile.is_open()) {
        outputFile<<"Let's write to the file the connectivity components that were obtained using DFS:"<<endl;
        for(vector<int>& i:svasn.dfsComponents){
            for(int j:i){
                outputFile<<j<<" ";
            }
            outputFile<<endl;
        }
        outputFile<<"Let's write to the file the connectivity components that were obtained using BFS:"<<endl;
        for(vector<int>& i:svasn.bfsComponents){
            for(int j:i){
                outputFile<<j<<" ";
            }
            outputFile<<endl;
        }
        outputFile<<endl<<"Number of connectivity components:"<<" ";
        outputFile<<svasn.bfsComponents.size();
        outputFile.close(); // Закрываем файл
    } else {
        std::cout << "The file could not be opened." << std::endl;
    }
}
vector<vector<int>> graph() {

    ifstream inputFile("C:/Users/PC/Desktop/bfs.txt"); // Открываем файл для чтения

    if (!inputFile.is_open()) {
        cout << "Файл не удалось открыть." << endl;
    }

    string line;
    vector<int> my_data; // Создаем вектор для чисел
    int digit1,digit2;
    int rebers,my_set_size;
    inputFile>>my_set_size>>rebers;

    int counter=0;
    while (true){
        counter+=1;
        inputFile>>digit1>>digit2;
        my_data.push_back(digit1);

        my_data.push_back(digit2);
        if(counter==rebers) break;
        //cout<<counter<<" ";
        //cout<<digit1<<" "<<digit2<<"\n";
    }

    // Теперь у вас есть вектор с числами
    inputFile.close(); // Закрываем файл


    for(int i:my_data){
        cout<<i<<" ";
    }

    //Для матрицы смежности
    bool matrix_sm[my_set_size][my_set_size];

    //Для матрицы инцидентности
    bool matrix_incedentn[my_set_size][rebers];

    vector<vector<int>> list_smechnosti(my_set_size);

    //задание матрицы смежности
    for(int i=0;i<my_set_size;i++)   {
        for(int j=0;j<my_set_size;j++){
            matrix_sm[i][j]=false;
        }
    }

    //задание матрицы инцидентности
    for(int i=0;i<my_set_size;i++)   {
        for(int j=0;j<rebers;j++){
            matrix_incedentn[i][j]=false;
        }
    }

    cout<<"\n";
    for(int i=0;i<my_data.size();i+=2) {
        int u,v;
        //cout<<my_data[i]<<" ";
        //т.к. индексация идёт с 0, а вершины начинаются с 1
        u=my_data[i];
        v=my_data[i+1];

        int pairINdex=i/2;

        list_smechnosti[u].push_back(v);
        list_smechnosti[v].push_back(u);

        matrix_sm[u][v] =true;
        matrix_sm[v][u]= true;


        matrix_incedentn[u][pairINdex]=true;

        matrix_incedentn[v][pairINdex]=true;


    }
    cout<<"Output the incidence matrix:"<<endl;

    // Вывод матрицы инцидентности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<rebers;j++){

            cout << matrix_incedentn[i][j] << ' ';

        }
        cout<<endl;}

    cout<<"Output the adjacency matrix:"<<endl;
    // Вывод матрицы смежности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<my_set_size;j++){

            cout << matrix_sm[i][j] << ' ';

        }
        cout<<endl;}

    cout<<"Output of the adjacency list:"<<endl;

    for(int i=0;i<my_set_size;i++){
        cout<<i<<":"<<endl;
        for(int c:list_smechnosti[i]){
            cout<<c<<" ";
        }
        cout<<endl;
    }
    return list_smechnosti;


}

#include <stack>


// Будем работать со списком смежности.

// Реализован обход графа в глубину
vector<int> DFS(vector<vector<int>>& graph, int start, vector<bool>& visited) {
    vector<int> componenta;
    if(!visited[start]){
        visited[start]=true;
        componenta.push_back(start);
        for(int i:graph[start]){
            vector<int> subcomponenta=DFS(graph,i, visited);
            componenta.insert(componenta.end(),subcomponenta.begin(),subcomponenta.end());
        }

        return componenta;
    }
}

// Реализация обхода графа в ширину
#include <queue>

vector<int> BFS(vector<vector<int>>& graph, int start, vector<bool>& visited) {
    queue<int> q;
    q.push(start);
    visited[start] = true;

    vector<int> component;

    while (!q.empty()) {
        int current = q.front();
        q.pop();
        component.push_back(current);
        /*
        // Можно вручную осуществить проверку
        cout<<"\n";
        cout<<current<<"\n";
        cout<<"!!"<<"\n";
        for(bool i:visited){
            cout<<i<<" ";
        }
        cout<<"\n";
        cout<<"!!"<<"\n";
*/
        for (int neighbor : graph[current]) {
            if (!visited[neighbor]) {
                q.push(neighbor);
                visited[neighbor] = true;
            }
        }
    }
    return component;
}



// Функция для нахождения всех компонент связности в графе
ConnectedComponents findAllConnectedComponents(vector<vector<int>>& graph) {
    int n = graph.size(); // Количество вершин в графе
    vector<bool> visited(n); // Массив для отслеживания посещенных вершин

    for(int i;i<n;i++) {
        visited[i]=false;
    }

    // Списки компонента компонент связности
    vector<vector<int>> components_dfs;
    vector<vector<int>> components_bfs;



    for (int i = 0; i < n; ++i) {
        if (!visited[i]) {
            vector<int> componenta;
            vector<int> component_dfs = DFS(graph, i, visited);
            components_dfs.push_back(component_dfs);

        }
    }
    /*
    cout<<"!!!"<<"\n";

    for (int i = 0; i < n; ++i){
        for(int j:graph[i]){
            cout<<j<<" ";

        }cout<<"\n";
    }
    cout<<"!!!"<<"\n";
*/
    vector<bool> visited_2(n); // Массив для отслеживания посещенных вершин

    for (int i = 0; i < n; ++i) {
        if (!visited_2[i]) {

            vector<int> component_bfs = BFS(graph, i, visited_2);
            /*
            for(bool v:visited_2 ){
                cout<<v<<" ";
            }
            cout<<"\n";
*/
            components_bfs.push_back(component_bfs);
        }
    }

    ConnectedComponents result;

    result.dfsComponents=components_dfs;
    result.bfsComponents=components_bfs;

    return result;
}



int main(){

    vector<vector<int>> my_g=graph();



    ConnectedComponents all_my_components=findAllConnectedComponents(my_g);

    //Компоненты связности неориентированного графа
    cout<<"Connectivity components of an undirected graph with DFS:"<<endl;


    //Зписываем в файл компоненты связности
    txt_file_input(all_my_components);

    for(vector<int>& i:all_my_components.dfsComponents){
        for(int j:i){
            cout<<j<<" ";
        }

        cout<<endl;
    }
    cout<<"Let's write to the file the connectivity components that were obtained using BFS:"<<endl;
    for(vector<int>& i:all_my_components.bfsComponents){
        for(int j:i){
            cout<<j<<" ";
        }

        cout<<endl;
    }
    cout<<endl<<"Number of connectivity components:"<<" ";
    cout<<all_my_components.bfsComponents.size();
    return 0;

}