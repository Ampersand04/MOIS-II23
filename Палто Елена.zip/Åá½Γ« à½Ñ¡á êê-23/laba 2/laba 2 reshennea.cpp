#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
using namespace std;
#include <algorithm>
#include <array>


struct haracteristics{
    vector<vector<int>> list_smechnosti;
    vector<vector<int>> matrix_inch;
};

struct solution{
    vector<int> hamelton;
    vector<int> euler;
};

struct graph{
    haracteristics eiler;
    haracteristics hamelton;
};

struct graphs{
    haracteristics first;
    haracteristics second;
};


//Если хотим записать/перезаписать данные в файл
void txt_file_input(solution res){
    std::ofstream outputFile; // Создаем объект для записи в файл
    // Открываем файл для записи
    outputFile.open("C:/Users/PC/Desktop/example_output.txt");
    if (outputFile.is_open()) {
        outputFile<<"The Hamiltonian cycle:"<<endl;
        for(int i:res.hamelton){
            outputFile<<i<<" ";
        }
        outputFile<<endl;

        outputFile<<"The Euler cycle:"<<endl;
        for(int i:res.euler){
            outputFile<<i<<" ";
        }
        outputFile<<endl;

        outputFile.close(); // Закрываем файл
    } else {
        std::cout << "The file could not be opened." << std::endl;
    }
}

// Функция для преобразования букв в цифры через аски
int letterToNumber(char letter) {
    return letter - 'a';
}

char numberToLetter(int number) {
    if (number >= 0 && number <= 25) {
        return 'a' + number;}}




haracteristics all_for_numeric_graph(ifstream& inputFile){
    string line;
    vector<int> my_data; // Создаем вектор для чисел
    int digit1,digit2;
    int rebers,my_set_size;
    inputFile>>my_set_size>>rebers;

    int counter=0;
    while (true){
        counter+=1;
        inputFile>>digit1>>digit2;
        my_data.push_back(digit1);

        my_data.push_back(digit2);
        if(counter==rebers) break;
    }

    // Теперь у вас есть вектор с числами
    inputFile.close(); // Закрываем файл


    for(int i:my_data){
        cout<<i<<" ";
    }

    //Для матрицы смежности
    vector<vector<int>> matrix_sm;

    //Для матрицы инцидентности
    bool matrix_incedentn[my_set_size][rebers];

    vector<vector<int>> list_smechnosti(my_set_size);

    //задание матрицы смежности
    for(int i=0;i<my_set_size;i++)   {
        vector<int> a;
        matrix_sm.push_back(a);
        for(int j=0;j<my_set_size;j++){
            matrix_sm[i].push_back(0);
        }
    }

    //задание матрицы инцидентности
    for(int i=0;i<my_set_size;i++)   {
        for(int j=0;j<rebers;j++){
            matrix_incedentn[i][j]=false;
        }
    }

    cout<<"\n";
    for(int i=0;i<my_data.size();i+=2) {
        int u,v;
        //cout<<my_data[i]<<" ";
        //т.к. индексация идёт с 0, а вершины начинаются с 1
        u=my_data[i];
        v=my_data[i+1];

        int pairINdex=i/2;

        list_smechnosti[u].push_back(v);
        list_smechnosti[v].push_back(u);

        matrix_sm[u][v] =true;
        matrix_sm[v][u]= true;


        matrix_incedentn[u][pairINdex]=true;

        matrix_incedentn[v][pairINdex]=true;


    }
    cout<<"Output the incidence matrix:"<<endl;

    // Вывод матрицы инцидентности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<rebers;j++){

            cout << matrix_incedentn[i][j]<< ' ';

        }
        cout<<endl;}

    cout<<"Output the adjacency matrix:"<<endl;
    // Вывод матрицы смежности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<my_set_size;j++){

            cout << matrix_sm[i][j] << ' ';

        }
        cout<<endl;}

    cout<<"Output of the adjacency list:"<<endl;

    for(int i=0;i<my_set_size;i++){
        cout<<i<<":"<<endl;
        for(int c:list_smechnosti[i]){
            cout<<c<<" ";
        }
        cout<<endl;
    }

    haracteristics my_gr;
    my_gr.matrix_inch=matrix_sm;
    my_gr.list_smechnosti=list_smechnosti;

    return my_gr;
}



//Если граф представлен буквами
haracteristics all_for_letter_graph(ifstream& inputFile){
    string line;
    vector<int> my_data; // Создаем вектор для чисел
    char a,b;
    int digit1,digit2;
    int rebers,my_set_size;
    inputFile>>my_set_size>>rebers;

    getline(inputFile,line);

    int counter=0;
    while (getline(inputFile,line)){
        istringstream iss(line);

        iss>>a>>b;
        cout<<a<<" "<<b;
        digit1=letterToNumber(a);
        digit2=letterToNumber(b);
        cout<<digit1<<" "<<digit2<<endl;

        my_data.push_back(digit1);
        my_data.push_back(digit2);
    }

    // Теперь у вас есть вектор с числами
    inputFile.close(); // Закрываем файл


    for(int i:my_data){
        cout<<i<<" ";
    }

    //Для матрицы смежности
    vector<vector<int>> matrix_sm;

    //Для матрицы инцидентности
    bool matrix_incedentn[my_set_size][rebers];

    vector<vector<int>> list_smechnosti(my_set_size);

    //задание матрицы смежности
    for(int i=0;i<my_set_size;i++)   {
        vector<int> a;
        matrix_sm.push_back(a);
        for(int j=0;j<my_set_size;j++){
            matrix_sm[i].push_back(0);
        }
    }

    //задание матрицы инцидентности
    for(int i=0;i<my_set_size;i++)   {
        for(int j=0;j<rebers;j++){
            matrix_incedentn[i][j]=false;
        }
    }

    cout<<"\n";
    for(int i=0;i<my_data.size();i+=2) {
        int u,v;
        //cout<<my_data[i]<<" ";
        //т.к. индексация идёт с 0, а вершины начинаются с 1
        u=my_data[i];
        v=my_data[i+1];

        int pairINdex=i/2;

        list_smechnosti[u].push_back(v);
        list_smechnosti[v].push_back(u);

        matrix_sm[u][v] =true;
        matrix_sm[v][u]= true;


        matrix_incedentn[u][pairINdex]=true;

        matrix_incedentn[v][pairINdex]=true;


    }
    cout<<"Output the incidence matrix:"<<endl;

    // Вывод матрицы инцидентности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<rebers;j++){

            cout << matrix_incedentn[i][j] << ' ';

        }
        cout<<endl;}

    cout<<"Output the adjacency matrix:"<<endl;
    // Вывод матрицы смежности
    for(int i=0;i<my_set_size;i++){
        for(int j=0;j<my_set_size;j++){

            cout << matrix_sm[i][j] << ' ';

        }
        cout<<endl;}

    cout<<"Output of the adjacency list:"<<endl;

    for(int i=0;i<my_set_size;i++){
        cout<<i<<":"<<endl;
        for(int c:list_smechnosti[i]){
            cout<<c<<" ";
        }
        cout<<endl;
    }

    haracteristics my_gr;
    my_gr.matrix_inch=matrix_sm;
    my_gr.list_smechnosti=list_smechnosti;

    return my_gr;
}

graphs graph() {

    cout<<"For the first:"<<endl;
    //Для графа с числами
    ifstream inputFile("C:/Users/PC/Desktop/lab 2 eil mois.txt"); // Открываем файл для чтения

    if (!inputFile.is_open()) {
        cout << "Файл не удалось открыть." << endl;
    }

    //Где хранится информация о 2 графах
    graphs my_graphs;

    my_graphs.first=all_for_numeric_graph(inputFile);

    //Для графа с буквами
    ifstream inputFile_1("C:/Users/PC/Desktop/lab 2 ham mois.txt"); // Открываем файл для чтения

    if (!inputFile_1.is_open()) {
        cout << "Файл не удалось открыть." << endl;
    }
    my_graphs.second=all_for_letter_graph(inputFile_1);

    return my_graphs;
}


//Для хранения стэка,результата и изменяющегося графа(при удалении рёбер)
struct Eiler{
    vector<int> C;
    vector<int> S;
    vector<vector<int>> graph;
};

#include <algorithm>
#include <iterator>

//Для удаления элемента по индексу
template <typename T>
void remove(std::vector<T> &v, size_t index)
{
    auto it = v.begin();
    std::advance(it, index);
    v.erase(it);
}


int search(vector<int> a,int i){
    for(int j;j<a.size();j++){
        if(a[j]==i) return j;
    }

}

#include <variant>

struct ham{
    vector<int> my;
    bool y_n;
};


ham Hamilton(haracteristics h,int curr,vector<bool>&Visited,vector<int>&Path){
    int n=h.list_smechnosti.size();

    Path.push_back(curr);
    //for(int i:Path) cout<<i<<" ";
    //cout<<endl;
    if(n==Path.size()){

        //Проверка что последняя вершина имеет хотя бы одно ребро с 1(первой) вершиной
        if (h.matrix_inch[Path[0]][Path.back()] == 1){
            ham q;
            q.my=Path;
            q.y_n=true;
            return q;
        }
        else{

            Path.pop_back();
            ham q;
            q.my=Path;
            q.y_n=false;
            return q;
        }}



    Visited[curr]=true;
    //Перебираем все вершины,которые связаны с текущей
    for(int next=0; next < n; next++){
        if (h.matrix_inch[curr][next] == 1 and !Visited[next]){
            ham res=Hamilton(h,next,Visited,Path);
            if(res.y_n){
                return res;

            }
        }
    }
    Visited[curr]=false;
    Path.pop_back();
    ham q;
    q.my=Path;
    q.y_n=false;
    return q;
}





Eiler obhod(vector<int> C,vector<int> S,vector<vector<int>> graph){
    reverse(S.begin(), S.end());
    vector<int>k=S;
    reverse(S.begin(), S.end());

    for(int i:k){
        if(graph[i].size()==0){
            C.push_back(i);
            S.pop_back();
        }
        else{
            while(true){
                if(graph[i].empty()) break;

                int a=graph[i][0];
                S.push_back(a);

                graph[i].erase(graph[i].begin());

                auto it=find(graph[a].begin(),graph[a].end(),i);
                if(it!=graph[a].end()) graph[a].erase(it);

                i=a;
            }
        }
        break;
    }


    Eiler z;
    z.C=C;
    z.S=S;
    z.graph=graph;
    return z;
}


// Функция для проверки существования эйлерова цикла
bool hasEulerCycle(vector<vector<int>>& graph) {
    int n = graph.size();

    // Проверяем, что граф связан
    for (int i = 0; i < n; i++) {
        if (graph[i].size() == 0) {
            return false; // Не связный граф
        }
    }

    // Проверяем, что степень каждой вершины четная
    for (int i = 0; i < n; i++) {
        if (graph[i].size() % 2 != 0) {
            return false; // Нечетные степени вершин
        }
    }

    return true;
}




vector<int> Eiler_cycle(vector<vector<int>>graph,int start){
    Eiler m;
    m.graph=graph;
    vector<int> C;
    vector<int> S;
    m.C=C;
    m.S=S;

    m.S.push_back(start);

    int a=-1;
    int point=start;

    while(a!=point){
        a = m.graph[start][0];
        remove(m.graph[start],0);

        remove(m.graph[a], search(m.graph[a],start));

        m.S.push_back(a);
        start=a;
    }

    while(!m.S.empty()){
        m= obhod(m.C,m.S,m.graph);
    }

    return m.C;

}


int main() {

    graphs my_g = graph();
    vector<int> C;
    vector<int> S;

    Eiler eil;
    eil.C = C;
    eil.S = S;
    eil.graph = my_g.first.list_smechnosti;

    vector<int> k;
    for (int i = 0; i < my_g.first.list_smechnosti.size(); i++) {
        sort(my_g.first.list_smechnosti[i].begin(), my_g.first.list_smechnosti[i].end());
    }

    //Проверяем существует ли эйлеров цикл в графе
    if (hasEulerCycle(my_g.first.list_smechnosti)) {
        k = Eiler_cycle(my_g.first.list_smechnosti, 0);
        cout << "The Euler cycle:" << endl;
        for (int i: k) {
            cout << i + 1 << " ";
        }
        cout << endl;
    } else {
        cout << "There is no Euler cycle in this graph" << endl;

    }

    //Инициируем все вершины как непосещённые
    vector<bool> Visited;
    for (int i = 0; i < my_g.second.list_smechnosti.size(); i++) Visited.push_back(false);

    vector<int> Path;

    ham ham_cycle = Hamilton(my_g.second, 1, Visited, Path);
    if (ham_cycle.y_n == true) {
        cout << "The Hamiltonian cycle:" << endl;
        for (int i = 0; i < ham_cycle.my.size(); i++) {
            cout << numberToLetter(ham_cycle.my[i]) << " ";
        }
    } else {
        cout << "There is no Hamiltonian cycle in this graph" << endl;
    }

    solution res;
    res.euler = k;
    res.hamelton = ham_cycle.my;

    //записываем результат в файл
    txt_file_input(res);

    return 0;

}