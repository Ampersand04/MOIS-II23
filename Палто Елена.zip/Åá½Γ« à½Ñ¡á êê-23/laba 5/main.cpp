﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

struct Edge {
    char start, end;
    int weight;
};

bool compareEdges(const Edge &a, const Edge &b) {
    return a.weight < b.weight;
}

class Graph {
private:
    vector<Edge> edges;
    int vertices;

public:
    Graph(int V) : vertices(V) {}

    void addEdge(char start, char end, int weight) {
        edges.push_back({start, end, weight});
    }

    void readGraphFromFile(const string &filename) {
        ifstream file(filename);
        if (file.is_open()) {
            file >> vertices;
            int numEdges;
            file >> numEdges;
            for (int i = 0; i < numEdges; ++i) {
                char start, end;
                int weight;
                file >> start >> end >> weight;
                addEdge(start, end, weight);
            }
            file.close();
        } else {
            cerr << "Unable to open file";
        }
    }

    void primAlgorithm() {
        vector<bool> visited(vertices, false);
        vector<int> MSTParent(vertices, -1);
        vector<int> key(vertices, INT_MAX);

        key[0] = 0;

        for (int i = 0; i < vertices - 1; ++i) {
            int minKey = INT_MAX, minIndex = -1;
            for (int j = 0; j < vertices; ++j) {
                if (!visited[j] && key[j] < minKey) {
                    minKey = key[j];
                    minIndex = j;
                }
            }

            visited[minIndex] = true;

            for (const Edge &edge : edges) {
                if (edge.start == minIndex + 'a' && !visited[edge.end - 'a'] && edge.weight < key[edge.end - 'a']) {
                    MSTParent[edge.end - 'a'] = minIndex;
                    key[edge.end - 'a'] = edge.weight;
                }
            }
        }

        cout << "Minimum Spanning Tree (Prim's Algorithm):" << endl;
        for (int i = 1; i < vertices; ++i) {
            if (MSTParent[i] != -1) {
                cout << char('a' + MSTParent[i]) << " - " << char('a' + i) << " : " << key[i] << endl;
            }
        }
    }


    void kruskalAlgorithm() {
        sort(edges.begin(), edges.end(), compareEdges);

        vector<int> parent(vertices);
        for (int i = 0; i < vertices; ++i) {
            parent[i] = i;
        }

        int edgesAccepted = 0;

        cout << "Minimum Spanning Tree (Kruskal's Algorithm):" << endl;

        for (const Edge &edge : edges) {
            int x = find(parent, edge.start - 'a');
            int y = find(parent, edge.end - 'a');

            if (x != y) {
                cout << edge.start << " - " << edge.end << " : " << edge.weight << endl;
                Union(parent, x, y);
                edgesAccepted++;
                if (edgesAccepted == vertices - 1) {
                    break;
                }
            }
        }
    }

    int find(vector<int> &parent, int vertex) {
        if (parent[vertex] != vertex) {
            parent[vertex] = find(parent, parent[vertex]);
        }
        return parent[vertex];
    }

    void Union(vector<int> &parent, int x, int y) {
        int xSet = find(parent, x);
        int ySet = find(parent, y);
        parent[xSet] = ySet;
    }
};

int main() {
    Graph graph(0); // Initialize graph with 0 vertices

    graph.readGraphFromFile("input.txt");

    graph.primAlgorithm();
    cout << endl;
    graph.kruskalAlgorithm();

    return 0;
}
