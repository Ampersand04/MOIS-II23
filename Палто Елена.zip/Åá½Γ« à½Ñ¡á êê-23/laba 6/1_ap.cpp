#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;
    vector<vector<int>> transpose();
    vector<vector<int>> scc; // Для хранения компонент сильной связности

    void fillOrder(int v, vector<bool>& visited, stack<int>& stack);
    void DFSUtil(int v, vector<bool>& visited, vector<int>& component);
    void printSCCUtil(vector<int>& component);

public:
    Graph(int V);
    void addEdge(int v, int w);
    void SCC();
    void printSCC();
};

Graph::Graph(int V) {
    this->V = V;
    adj.resize(V);
}

vector<vector<int>> Graph::transpose() {
    vector<vector<int>> transposed(V);
    for (int v = 0; v < V; ++v) {
        for (int i = 0; i < adj[v].size(); ++i) {
            transposed[adj[v][i]].push_back(v);
        }
    }
    return transposed;
}

void Graph::addEdge(int v, int w) {
    adj[v].push_back(w);
}

void Graph::fillOrder(int v, vector<bool>& visited, stack<int>& stack) {
    visited[v] = true;
    for (int i = 0; i < adj[v].size(); ++i) {
        if (!visited[adj[v][i]]) {
            fillOrder(adj[v][i], visited, stack);
        }
    }
    stack.push(v);
}

void Graph::DFSUtil(int v, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v);

    for (int i = 0; i < adj[v].size(); ++i) {
        if (!visited[adj[v][i]]) {
            DFSUtil(adj[v][i], visited, component);
        }
    }
}

void Graph::SCC() {
    stack<int> stack;
    vector<bool> visited(V, false);

    for (int v = 0; v < V; ++v) {
        if (!visited[v]) {
            fillOrder(v, visited, stack);
        }
    }

    vector<vector<int>> transposed = transpose();

    fill(visited.begin(), visited.end(), false);

    while (!stack.empty()) {
        int v = stack.top();
        stack.pop();

        if (!visited[v]) {
            vector<int> component;
            DFSUtil(v, visited, component);
            scc.push_back(component);
        }
    }
}

void Graph::printSCCUtil(vector<int>& component) {
    for (int i = 0; i < component.size(); ++i) {
        cout << char(component[i] + 'a') << " ";
    }
    cout << endl;
}

void Graph::printSCC() {
    for (int i = 0; i < scc.size(); ++i) {
        cout << "Component " << i + 1 << ": ";
        printSCCUtil(scc[i]);
    }
}

int main() {
    ifstream file("input.txt");
    int vertices, edges;
    file >> vertices >> edges;

    Graph graph(vertices);

    for (int i = 0; i < edges; ++i) {
        char start, end;
        file >> start >> end;
        graph.addEdge(start - 'a', end - 'a');
    }

    cout << "Strongly Connected Components are:\n";
    graph.SCC();
    graph.printSCC();

    return 0;
}
