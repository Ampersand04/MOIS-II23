#include <iostream>
#include <vector>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <set>

using namespace std;

vector <vector <int> > createTable(vector <int> A){
    const int ASize = A.size();
    vector <vector <int>> result (ASize, vector <int> (ASize));
    for (int i = 0; i < ASize; i++)
        for (int j = 0; j < ASize; j++)
            result[i][j] = (A[i] * A[j]) % 11;
    return result;
}

void printTable(vector <vector <int> > table, vector <int> A){
    int ASize = A.size();
    cout << "  *|";
    for (int i = 1; i <= ASize; i++)
        cout << setw(3) << A[i-1];
    cout << "\n---+";
    for (int i = 0; i < (ASize)*3; i++)
        cout << "-";
    cout << '\n';
    for (int i = 0; i < ASize; i++){
        cout << setw(3) << A[i] << "|";
        for (int j = 0; j < ASize; j++){
            cout << setw(3) << table[i][j];
        }
        cout << '\n';
    }

}

std::set<int> leftCoset(int element, const vector<int>& subgroup) {
    std::set<int> result;
    for (int h : subgroup) {
        result.insert((element * h) % 11);
    }
    return result;
}

void print_set(const set<int>& s) {
    cout << "{ ";
    for (int x : s)
        cout << x << " ";
    cout << "}";
}

int main() {

    vector <int> A{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    const int ASize = A.size();
    vector <vector <int> > CaylesTable = createTable(A);
    printTable(CaylesTable, A);

    int neutral;

    for (int i = 0, flag = 0; i < ASize; i++){
        for (int j = 0; j < ASize; j++){
            if (CaylesTable[i][j] != A[j]){
                flag = 1;
                break;
            }
        }
        if (!flag){
            neutral = A[i];
            break;
        }
    }

    cout << "neutral element: " << neutral << "\n";
    cout << "inverse elements:\n";
    for (int i = 0; i < ASize; i++) {
        for (int j = 0; j < ASize; j++) {
            if (CaylesTable[i][j] == neutral) {
                cout << A[i] << ":" << A[j] << '\n';
            }
        }
    }

    cout << "order of an elements:\n";
    vector <vector <int> > groups;
    bool isCyclical = false;
    for (int i = 0; i < ASize; i++){
        int value = A[i], step = 1;
        vector <int> tempGroup;
        bool flag = true;
        while (value != 1){
            if (std::find(tempGroup.begin(), tempGroup.end(), value) != tempGroup.end()){
                flag = false;
                break;
            }
            tempGroup.push_back(value);
            value = value * A[i] % 11;
            step++;
        }
        if (flag) {
            tempGroup.push_back(value);
            sort(tempGroup.begin(), tempGroup.end());
            groups.push_back(tempGroup);
            cout << A[i] << ':' << step << '\n';
            if (step == ASize)
                isCyclical = true;
        } else {
            cout << A[i] << ": inf" << '\n';

        }
    }
    sort(groups.begin(), groups.end());
    groups.erase(unique(groups.begin(), groups.end()), groups.end());

    if (isCyclical)
        cout << "Group is cyclical\n";
    else
        cout << "Group not cyclical\n";

    cout << "Groups:\n";
    for (auto group : groups){
        cout << '{' << group[0];
        for (int i = 1; i < group.size(); i++)
            cout  << ',' << group[i];
        cout << "}, the generating element: " << group[1] << '\n';
    }

    auto anotherTable = createTable(groups[2]);
    printTable(anotherTable, groups[2]);

    for (const vector<int>& subgroup : groups) {
        cout << "Subgroup: {" << subgroup[0];
        for (int i = 1; i < subgroup.size(); i++)
            cout << "," << subgroup[i];
        cout << "}\n";
        set<set<int>> cosets;
        for (int element : A) {
            cosets.insert(leftCoset(element, subgroup));
        }
        cout << "\nFactor sets: \n";
        for (const auto& coset : cosets) {
            print_set(coset);
            cout << "\n";
        }
        cout << "\n";
    }
}