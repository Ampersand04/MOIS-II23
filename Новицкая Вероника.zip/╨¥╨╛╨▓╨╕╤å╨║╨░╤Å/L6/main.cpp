#include <iostream>
#include <vector>
#include <fstream>
#include <stack>

using namespace std;

vector<vector<int>> g;
vector<int> tin, fup;
vector<bool> used;
stack<int> st;
int timer = 0;

vector<vector<int>> adj, adj_rev;
vector<bool> used1;
vector<int> order, component;
stack<int> s;
ofstream file2("result.txt");

void dfs(int v, int p = -1) {
    used[v] = true;
    tin[v] = fup[v] = timer++;
    st.push(v);
    for (size_t i = 0; i < g[v].size(); ++i) {
        int to = g[v][i];
        if (to == p) continue;
        if (used[to])
            fup[v] = min(fup[v], tin[to]);
        else {
            dfs(to, v);
            fup[v] = min(fup[v], fup[to]);
            if (fup[to] >= tin[v]) {
                cout << "Компонента:";
                file2 << "Компонента:";
                while (true) {
                    int x = st.top();
                    st.pop();
                    cout << " " << x;
                    file2 << " " << x;
                    if (x == to) break;
                }
                cout << endl;
                file2 << endl;
            }
        }
    }
}

void dfs1(int v) {
    used1[v] = true;
    for (size_t i = 0; i < adj[v].size(); ++i)
        if (!used1[adj[v][i]])
            dfs1(adj[v][i]);
    order.push_back(v);
}

void dfs2(int v) {
    used1[v] = true;
    component.push_back(v);
    for (size_t i = 0; i < adj_rev[v].size(); ++i)
        if (!used1[adj_rev[v][i]])
            dfs2(adj_rev[v][i]);
}

int main() {
    setlocale(LC_ALL, "Russian");
    ifstream file("graph.txt");
    int n;
    file >> n;
    adj.resize(n);
    adj_rev.resize(n);
    used1.assign(n, false);
    while (!file.eof()) {
        int u, v;
        file >> u >> v;
        adj[u - 1].push_back(v - 1);
        adj_rev[v - 1].push_back(u - 1);
    }3
    file.close();
    for (int i = 0; i < n; ++i)
        if (!used1[i])
            dfs1(i);
    used1.assign(n, false);
    cout << "Компоненты сильной связности орграфа:" << endl;
    file2 << "Компоненты сильной связности орграфа:" << endl;
    for (int i = 0; i < n; ++i) {
        int v = order[n - 1 - i];
        if (!used1[v]) {
            dfs2(v);
            for (int j = 0; j < component.size(); ++j) {
                cout << component[j] + 1 << ' ';
                file2 << component[j] + 1 << ' ';
            }
            cout << endl;
            file2 << endl;
            component.clear();
        }
    }


    ifstream file1("graph1.txt");
    int n1, m1;
    file1 >> n1 >> m1;
    cout << endl << "Компоненты двусвязности:" << endl;
    file2 << endl << "Компоненты двусвязности:" << endl;
    g.resize(n1);
    tin.resize(n1);
    fup.resize(n1);
    used.assign(n1, false);
    for (int i = 0; i < m1; ++i) {
        int a, b;
        file1 >> a >> b;
        --a; --b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    for (int i = 0; i < n1; ++i)
        if (!used[i])
            dfs(i);
    file1.close();
    file2.close();
    return 0;
}

