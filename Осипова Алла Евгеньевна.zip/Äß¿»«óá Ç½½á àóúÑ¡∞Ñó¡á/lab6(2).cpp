#include <iostream>
#include <vector>
#include <list>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

class Graph {
    int V;
    unordered_map<char, list<char>> adj;

    void tarjanDFS(char u, unordered_map<char, int>& disc, unordered_map<char, int>& low, unordered_map<char, char>& parent, vector<vector<char>>& result);

public:
    Graph(int V);
    void addEdge(char v, char w);
    void findBiconnectedComponents();
    void readGraphFromFile(const string& filename);
};

Graph::Graph(int V) {
    this->V = V;
}

void Graph::addEdge(char v, char w) {
    adj[v].push_back(w);
    adj[w].push_back(v);
}

void Graph::tarjanDFS(char u, unordered_map<char, int>& disc, unordered_map<char, int>& low, unordered_map<char, char>& parent, vector<vector<char>>& result) {
    static int time = 0;
    disc[u] = low[u] = ++time;
    int children = 0;
    bool isArticulation = false;

    for (char v : adj[u]) {
        if (disc[v] == 0) {
            children++;
            parent[v] = u;
            tarjanDFS(v, disc, low, parent, result);

            low[u] = min(low[u], low[v]);

            if ((parent[u] == '\0' && children > 1) || (parent[u] != '\0' && low[v] >= disc[u])) {
                isArticulation = true;
            }

            if (low[v] > disc[u]) {
                result.push_back({ u, v });
            }
        }
        else if (v != parent[u]) {
            low[u] = min(low[u], disc[v]);
        }
    }

    if (isArticulation) {
        vector<char> component;
        while (true) {
            char node = u;
            component.push_back(node);
            if (node == parent[u])
                break;
            u = parent[u];
        }
        result.push_back(component);
    }
}

void Graph::findBiconnectedComponents() {
    unordered_map<char, int> disc;
    unordered_map<char, int> low;
    unordered_map<char, char> parent;
    vector<vector<char>> result;

    for (auto& it : adj) {
        char u = it.first;
        if (disc[u] == 0) {
            tarjanDFS(u, disc, low, parent, result);
        }
    }

    cout << "Biconnected components in the graph:\n";
    for (const auto& component : result) {
        for (char node : component) {
            cout << node << " ";
        }
        cout << endl;
    }
}

void Graph::readGraphFromFile(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "������ �������� �����\n";
        return;
    }

    string line;
    char v, w;
    int edges;

    if (getline(file, line)) {
        istringstream iss(line);
        iss >> V >> edges;
    }

    for (int i = 0; i < edges; ++i) {
        if (getline(file, line)) {
            istringstream iss(line);
            iss >> v >> w;
            addEdge(v, w);
        }
    }

    file.close();
}

int main() {
    Graph g(0);
    g.readGraphFromFile("graph.txt");
    g.findBiconnectedComponents();

    return 0;
}
