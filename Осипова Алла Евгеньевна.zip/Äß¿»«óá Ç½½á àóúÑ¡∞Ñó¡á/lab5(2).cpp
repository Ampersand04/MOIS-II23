﻿#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int u, v, weight;
};

bool compareEdges(const Edge &a, const Edge &b) {
    return a.weight < b.weight;
}

int findParent(int node, vector<int> &parent) {
    if (parent[node] == node)
        return node;
    return findParent(parent[node], parent);
}

void unionNodes(int u, int v, vector<int> &parent, vector<int> &rank) {
    int rootU = findParent(u, parent);
    int rootV = findParent(v, parent);

    if (rank[rootU] < rank[rootV])
        parent[rootU] = rootV;
    else if (rank[rootU] > rank[rootV])
        parent[rootV] = rootU;
    else {
        parent[rootV] = rootU;
        rank[rootU]++;
    }
}

void kruskal(vector<Edge> &edges, int numNodes) {
    vector<int> parent(numNodes);
    vector<int> rank(numNodes, 0);

    for (int i = 0; i < numNodes; ++i)
        parent[i] = i;

    vector<Edge> mst;
    int mstWeight = 0;

    sort(edges.begin(), edges.end(), compareEdges);

    for (Edge &edge : edges) {
        if (findParent(edge.u, parent) != findParent(edge.v, parent)) {
            mst.push_back(edge);
            mstWeight += edge.weight;
            unionNodes(edge.u, edge.v, parent, rank);
        }
    }

    cout << "Minim ost tree(Kruskal):\n";
    for (Edge &edge : mst) {
        cout << char('a' + edge.u) << " - " << char('a' + edge.v) << " : " << edge.weight << "\n";
    }
}

int main() {
    vector<Edge> edges = {
            {0, 1, 2}, {0, 2, 3}, {1, 2, 4}, {2, 3, 5},
            {2, 6, 7}, {3, 6, 6}, {3, 4, 3}, {3, 5, 5},
            {6, 7, 1}, {6, 8, 1}, {4, 5, 1}, {7, 8, 2}
    };

    kruskal(edges, 9);

    return 0;
}
