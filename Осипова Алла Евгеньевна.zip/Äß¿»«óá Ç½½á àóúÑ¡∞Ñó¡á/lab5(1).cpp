﻿#include <iostream>
#include <vector>
#include <queue>
#include <utility>
#include <algorithm>

using namespace std;

#define INF 1000000000

typedef pair<int, int> pii;
vector<vector<pii>> graph;

void prim(int start) {
    vector<bool> visited(graph.size(), false);
    vector<int> min_cost(graph.size(), INF);
    vector<int> parent(graph.size(), -1);

    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push({0, start});
    min_cost[start] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();
        visited[u] = true;

        for (pii &neighbor : graph[u]) {
            int v = neighbor.first;
            int weight = neighbor.second;

            if (!visited[v] && weight < min_cost[v]) {
                min_cost[v] = weight;
                parent[v] = u;
                pq.push({min_cost[v], v});
            }
        }
    }


    cout << "The minimal ost tree(Prima alg): \n";
    for (int i = 0; i < graph.size(); ++i) {
        if (parent[i] != -1) {
            cout << char('a' + parent[i]) << " - " << char('a' + i) << " : " << min_cost[i] << "\n";
        }
    }
}

int main() {
    graph.resize(9);

    vector<pair<pair<int, int>, int>> edges = {
            {{0, 1}, 2}, {{0, 2}, 3}, {{1, 2}, 4}, {{2, 3}, 5},
            {{2, 6}, 7}, {{3, 6}, 6}, {{3, 4}, 3}, {{3, 5}, 5},
            {{6, 7}, 1}, {{6, 8}, 1}, {{4, 5}, 1}, {{7, 8}, 2}
    };

    for (auto &edge : edges) {
        int u = edge.first.first;
        int v = edge.first.second;
        int weight = edge.second;

        graph[u].push_back({v, weight});
        graph[v].push_back({u, weight});
    }

    // Запуск алгоритма Прима
    prim(0);

    return 0;
}
